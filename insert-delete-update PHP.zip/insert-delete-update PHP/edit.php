	<?php
	session_start();
	if ($_SESSION["uname"]) {
		echo "";
	} else {
		header('location:login.php');
	}
	?>



<?php
	$host = mysql_connect('localhost', 'root', '') or die("Connection error");
	$db = mysql_select_db('newuser') or die('database error');
	$id = $_REQUEST['id'];


	$query = "select * from profile where id=" . $id;
	$res = mysql_query($query);
	$row = mysql_fetch_assoc($res);
	$hobby = explode(',', $row['hobby']);



		if (isset($_POST['submit'])) {
			$id = $_POST['id'];
			$fname = $_POST['fname'];
			$lname = $_POST['lname'];
			$date = $_POST['date'];
			$email = $_POST['email'];
			$gender = $_POST['gender'];
			$hobby1 = implode(',', $_POST['hobby']);

		if ($_FILES['photo']['name'] != "") {
			$photoName = $_FILES['photo']['name'];
			$file = $_FILES["photo"]["name"];
			$temp_name = $_FILES["photo"]["tmp_name"];
			$path = "images/".$file;
			$file1 = explode(".", $file);
			$ext = $file1[1];
			$allowed = array("jpg", "png", "gif");
              
	
			if (in_array($ext, $allowed)) {
				move_uploaded_file($temp_name, $path);
			}
			} else {
					$photoName = $_REQUEST['photoname'];
			}
	
		$query = 'update profile set fname="' . $fname . '",lname="' . $lname . '",date="' . $date . '",email="' . $email . '",gender="' . $gender . '",photo="' . $photoName . '",hobby="' . $hobby1 . '" where id=' . $id;
	
		if (mysql_query($query)) {
			header("Location:view.php");
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>

        <link rel="stylesheet" href="css/datepicker.css" type="text/css" />
        <link rel="stylesheet" media="screen" type="text/css" href="css/layout.css" />

        <script type="text/javascript" src="js/jquery.js"></script>
        <script type="text/javascript" src="js/datepicker.js"></script>
        <script type="text/javascript" src="js/eye.js"></script>
        <script type="text/javascript" src="js/utils.js"></script>
        <script type="text/javascript" src="js/layout.js?ver=1.0.2"></script>
        <script type="text/javascript" src="js/script.js"></script>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Edit</title>
    </head>
    <body>
        <form  method="post"  enctype="multipart/form-data">
            <table align="center" border="3" bordercolor="#000099">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>" />
                <tr>
                    <th>First Name </th>
                    <td><input type="text" name="fname" size="30" value="<?php echo $row['fname']; ?>"/></td>
                </tr> 
                <tr>
                    <th>Last Name </th>
                    <td><input type="text" name="lname" size="30" value="<?php echo $row['lname']; ?>" /></td>
                </tr>
                <tr>
                    <th>Date Of Birth</th>
                    <td><input class="inputDate" id="inputDate" name="date" value="<?php echo $row['date']; ?>" required /></b>
                    </td>

                    <tr>

                        <tr>
                            <th>Email </th>
                            <td><input type="text" name="email" size="30" value="<?php echo $row['email']; ?>" /></td>
                        </tr>
                        <?php /* ?><tr>
                          <th>Genger</th>
                          <td>
                          <input type="radio" name="gender"
                          <?php if (isset($gender) && $gender=="male") {echo "checked";}?> value="male">Male
                          <input type="radio" name="gender"
                          <?php if (isset($gender) && $gender=="female") {echo "checked";}?> value="female">Female
                          </td>
                          </tr><?php */ ?>


                        <tr>
                            <th>Gender</th>

                            <td><input type="radio" name="gender" value="Male" checked="checked"  />Male
                                <input type="radio" name="gender" value="Female" />Female
                            </td>
                        </tr>
                        <tr>
                            <th>Photo</th>
                            <td><input type="file" name="photo" value="<?php echo $row['photo']; ?>"/>
                                <img src="images/<?php echo $row["photo"] ?> "height="80" width="150">
                                    <input type="hidden" name="photoname" value="<?php echo $row['photo'] ?>"/></td> 
                        </tr>
                        <tr>
                            <th>Hobby</th>
                            <td> 
                                <input type="checkbox" name="hobby[]" value="playing" <?php
                                foreach ($hobby as $value) {
                                    if ($value == 'playing') {
                                        echo "checked";
                                    }
                                }
                                ?>  />playing
                                <input type="checkbox" name="hobby[]" value="traveling" <?php
                                foreach ($hobby as $value) {
                                    if ($value == 'traveling') {
                                        echo "checked";
                                    }
                                }
                                ?>  />traveling
                                <input type="checkbox" name="hobby[]" value="reading" <?php
                                foreach ($hobby as $value) {
                                    if ($value == 'reading') {
                                        echo "checked";
                                    }
                                }
                                ?>  />reading

                                <input type="checkbox" name="hobby[]" value="watching" <?php
                                foreach ($hobby as $value) {
                                    if ($value == 'watching') {
                                        echo "checked";
                                    }
                                }
                                ?>  />watching  

                            </td>

                        </tr>



                        <tr>
                            <td colspan="2" align="center"><input type="submit" value="submit" name="submit" /></td>
                        </tr>


                        </table>


                        </form>

                        </body>
                        </html>
                        
                       