<?php
session_start();

if ($_SESSION["uname"]) {
    echo "";
} else {
    header('location:login.php');
}
?>

<?php
$host = mysql_connect('localhost', 'root', '') or die("Connection error");
$db = mysql_select_db('newuser') or die('database error');


$uname = $_SESSION["uname"];
$query = "select * from profile where uname='$uname'";

$q = mysql_query($query) or die("Query problem");


echo "<table align=center border=15>
	<tr>
	    <th>Fname</th>
		<th>Lname</th>
		<th>Birthdate</th>
		<th>Email</th>
		<th>Gender</th>
		<th>Hobby</th>
		<th>Photo</th>
		<th>Delete</th>
		<th>Edit</th>
   </tr>";

while ($data = mysql_fetch_array($q)) {

    extract($data);
    echo "<tr>";
    echo "<td>" . $fname . "</td>";
    echo "<td>" . $lname . "</td>";
    echo "<td>" . $date . "</td>";
    echo "<td>" . $email . "</td>";
    echo "<td>" . $gender . "</td>";
    echo "<td>" . $hobby . "</td>";
    ?>

    <td> <img src="images/<?php echo $data["photo"] ?> "height="50" width="100"></td> 




    <td><a href="delete.php?id=<?php echo $id ?>"> Delete </a></td>
    <td><a href="edit.php?id=<?php echo $id ?>"> Edit </a></td>

    <?php
}
?>	
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>View Detail</title>
</head>



<body>

    <h1 align="center">View Detail</h1>
     <h1 align="center">===========</h1>
     
    <p style align="right"> <?php echo "welcome" . " " . $_SESSION["uname"] ?> &nbsp;&nbsp;<a href="logout.php">Logout</a></p>
    

</body>