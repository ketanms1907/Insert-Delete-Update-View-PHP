<?php
session_start();
?>
<?php
if (isset($_REQUEST['submit'])) {

    $host = mysql_connect('localhost', 'root', '') or die("Connection error");
    $db = mysql_select_db('newuser') or die('database error');
	
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $uname = $_POST['uname'];
    $pass = $_POST['pass'];
    $date = $_POST['date'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    move_uploaded_file($_FILES['photo']['tmp_name'], 'images/' . $_FILES['photo']['name']);
    $file = $_FILES['photo']['name'];
    $hobby = implode(',', $_POST['hobby']);
    
   
     $query = 'insert into profile (fname,lname,uname,pass,date,email,gender,photo,hobby) values ("' . $fname . '","' . $lname . '","' . $uname . '","' . $pass . '","' . $date . '","' . $email . '","' . $gender . '","' . $file . '","' . $hobby . '")';
           
     
	if (mysql_query($query)) {
		header("Location:view.php");
	} else {
		header("Location:newuser.php");
	}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="css/datepicker.css" type="text/css" />
<link rel="stylesheet" media="screen" type="text/css" href="css/layout.css" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/datepicker.js"></script>
<script type="text/javascript" src="js/eye.js"></script>
<script type="text/javascript" src="js/utils.js"></script>
<script type="text/javascript" src="js/layout.js?ver=1.0.2"></script>
<script type="text/javascript" src="js/newuserscript.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>New User</title>
</head>

<body>
<form action="" method="post" name="f1" enctype="multipart/form-data" >
  <table align="center" border="1" bordercolor="">
    <tr>
      <th colspan="2" align="center" bgcolor=""><h1>PROFILE </h1></th>
    </tr>
    <tr>
      <th>First Name </th>
      <td><input type="text" name="fname" id="fname" size="20" placeholder="Ente First Name" /></td>
    </tr>
    <tr>
      <th>Last Name </th>
      <td><input type="text" name="lname" id="lname" size="20"  placeholder="Enter Second Name"  /></td>
    </tr>
    <tr>
    <tr>
      <th>Username </th>
      <td><input type="text" name="uname" id="uname" size="20" placeholder="Ente  User Name"  /></td>
    </tr>
    <tr>
      <th>password </th>
      <td><input type="password" name="pass" id="password" size="20"  placeholder="Enter Password"  /></td>
    </tr>
    <tr>
      <th>Date Of Birth</th>
      <td><input class="inputDate" id="inputDate" name="date" value="01/31/2015"  />
        </b></td>
    </tr>
    <tr>
      <th>Email </th>
      <td><input type="text" name="email" id="email" size="30" placeholder="Enter Email Address" /></td>
    <tr>
      <th>Gender</th>
      <td><input type="radio" name="gender" id="gnd" value="Male"   />
        Male
        <input type="radio" name="gender" id="gnd" value="Female" />
        Female </td>
    </tr>
    <tr>
      <th>Photo</th>
      <td><input type="file" name="photo" id="photo"   /></td>
    </tr>
    <tr>
      <th>Hobby</th>
      <td><input type="checkbox" id="selectall" value="SelectAll"/>
        All Hobby
        <input type="checkbox" name="hobby[]" value="playing" class="case"/>
        playing
        <input type="checkbox" name="hobby[]" value="traveling" class="case"/>
        traveling
        <input type="checkbox" name="hobby[]" value="reading" class="case"/>
        reading
        <input type="checkbox" name="hobby[]" value="watching" class="case"/>
        watching </td>
    </tr>
    <tr>
      <td colspan="2" align="center"><input type="submit" id="submit" value="submit" name="submit" />
        <input type="reset" value="Reset" name="Reset" /></td>
    </tr>
  </table>
</form>
</body>
</html>