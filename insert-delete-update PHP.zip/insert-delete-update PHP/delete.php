<?php
session_start(); 
if($_SESSION["uname"])
{
	echo "";
}
else
{
	header('location:login.php');
}
?>

<?php
    
	$host=mysql_connect('localhost','root','') or die ("Connection error");
	$db=mysql_select_db('newuser') or die ('database error');
	
	$id=$_REQUEST['id'];
	
	$query="delete from profile where id='".$id."'";
	$q=mysql_query($query) or die ("Query problem");
	
	if($q==1)
	{
			header("Location:view.php");
	}
	
?>
	

	