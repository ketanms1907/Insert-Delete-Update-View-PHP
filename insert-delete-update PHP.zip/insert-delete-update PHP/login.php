<?php
if (isset($_REQUEST["submit"])) {
    $host = mysql_connect('localhost', 'root', '') or die("Connection error");
    $db = mysql_select_db('newuser') or die('database error');

    $uname = $_REQUEST["uname"];
    $pass = $_REQUEST["pass"];

    $query = mysql_query("select * from profile where uname='$uname' and pass='$pass'");
    $rows = mysql_num_rows($query);

    if ($rows > 0) {
        session_start();
        $_SESSION['uname'] = $uname;
        header('location:view.php');
    } else {
        echo "<script>alert('your username and password is wrong');</script>";
    }
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <script type="text/javascript" src="js/jquery.js"></script>
        <script type="text/javascript" src="js/script.js"></script>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>login</title>
    </head>
    <body>
        <form action="" name="f1" enctype="multipart/form-data" method="post"  >
       
           <h1><td><center>Login</center></td></h1>
            <table border="10" align="center" bgcolor="#CCCCCC">
                <tr>
                    <th>Username</th>
                    <td><input type="text" name="uname" id="uname"  /></td>
                </tr>
                <tr>
                    <th>Password</th>
                    <td><input type="password" name="pass" id="password"  /></td>
                </tr>
                <tr>
                    <td colspan="2" align="center"><input type="submit" id="submit" value="Login" name="submit" />
                        <input type="reset"  value="Reset" name="reset" /></td>
                </tr>
                <th><a href="newuser.php">For Register User</a></th>
            </table>
        </form>
    </body>
</html>