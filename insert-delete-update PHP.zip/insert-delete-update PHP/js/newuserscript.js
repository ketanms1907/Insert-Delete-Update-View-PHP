$(document).ready(function () {

    $("#fname").focus(function () {
        $(this).css("background-color", "#cccccc");
    })
    $('#fname').blur(function () {
        $(this).css("background-color", "#ffffff");
        if (this.value == "") {
            alert("Enter Your First Name");
            
            
            $('#fname').focus();
        }
        $("#lname").focus(function(){
        $(this).css("background-color", "#cccccc");
    })  

        $('#lname').blur(function () {
            $(this).css("background-color", "#ffffff");
            if (this.value == "") {
                alert("Enter Your Last Name");
            }
        });
        $("#uname").focus(function () {
        $(this).css("background-color", "#cccccc");
    })
        $('#uname').blur(function () {
            $(this).css("background-color", "#ffffff");
            if (this.value == "") {
                alert("Enter Your User Name");
            }
        });

        $("#password").focus(function () {
        $(this).css("background-color", "#cccccc");
    })
        
        $('#password').blur(function () {
            $(this).css("background-color", "#ffffff");
            if (this.value == "") {
                alert("Enter Your Password");
            }
        });


        $("#gndmale").click(function () {
//        var a = $("#gndmale").prop('checked', true);
            alert("You Selected Male");
        });

$("#email").focus(function () {
        $(this).css("background-color", "#cccccc");
    })

        $('#email').blur(function () {
            $(this).css("background-color", "#ffffff");
            var sEmail = $('#email').val();
            if ($.trim(sEmail).length == 0) {
                alert('Please enter valid email address');
                // e.preventDefault();
            }
            if (validateEmail(sEmail)) {
                alert('Email is valid');
            }
            else {
                alert('Invalid Email Address');
                // e.preventDefault();
            }
        });

        $(function () {
            $("#submit").click(function () {
                ($("input[name=gnd]:checked").val());
                alert("Select Your Gender");

            });

            $('#submit').click(function () {
                $("#hobby").toggle(this.checked);
                alert("Select Hobby");

            });



            $("#selectall").click(function () {
                $('.case').attr('checked', this.checked);
            });
            $(".case").click(function () {
                if ($(".case").length == $(".case:checked").length) {
                    $("#selectall").attr("checked", "checked");
                } else {
                    $("#selectall").removeAttr("checked");
                }
            });

        });




    });

    function validateEmail(sEmail) {
        var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
        if (filter.test(sEmail)) {
            return true;
        }
        else {
            return false;
        }
    }


    /*$('#email').blur(function () {
     if (this.value == "") {
     alert("Enter Your Email Address");
     
     }
     });
     
     
     function IsEmail(email) {
     var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     return regex.test(email);
     }
     */
});
