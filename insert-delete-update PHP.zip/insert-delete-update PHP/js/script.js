

$(document).ready(function () {
    $('#uname').blur(function () {
        if (this.value == "") {
            alert("Please Enter Your Username");
            $('#uname').focus();
        }
    });

    $('#password').blur(function () {
        if (this.value == "") {
      
        alert("Please Enter Your Password");
    }
    });

//    $('#submit').click(function () {
//        if ($('#uname').value == "" || $('#password').value == "") {
//        alert("Please Enter Your Username and Password");
//    }
//    });
});

